from pathlib import Path
import json, shutil, time, uuid

class Quarantine:
    def __init__(self,root=None):
        self.root=Path(root or Path.home()/".chlorine"/"quarantine")
        self.root.mkdir(parents=True,exist_ok=True); self.index=self.root/"index.json"
        if not self.index.exists(): self.index.write_text("[]")
    def _read(self): return json.loads(self.index.read_text())
    def _write(self,x): self.index.write_text(json.dumps(x,indent=2))
    def move(self,path):
        src=Path(path).expanduser().resolve()
        if not src.exists(): raise FileNotFoundError(src)
        dst=self.root/f"{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}-{src.name}"
        shutil.move(str(src),str(dst))
        a=self._read(); a.append({"id":dst.name,"original":str(src),"quarantined":str(dst)}); self._write(a)
        return dst
    def restore(self,item_id):
        a=self._read()
        for x in a:
            if x["id"]==item_id:
                src,dst=Path(x["quarantined"]),Path(x["original"])
                dst.parent.mkdir(parents=True,exist_ok=True); shutil.move(str(src),str(dst))
                a.remove(x); self._write(a); return dst
        raise KeyError(item_id)
