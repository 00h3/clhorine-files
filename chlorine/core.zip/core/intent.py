import re
from dataclasses import dataclass

@dataclass
class Intent:
    action:str
    target:str
    confidence:float
    reason:str

def parse(q):
    s=q.lower().strip()
    destructive=any(x in s for x in ("delete","remove","erase","trash","get rid of"))
    if destructive: return Intent("delete",target(s),.96,"destructive request detected")
    if any(x in s for x in ("duplicate","duplicates","copies")): return Intent("duplicates",target(s),.93,"duplicate-file request detected")
    if any(x in s for x in ("biggest","largest","large","space","storage")): return Intent("large",target(s),.91,"storage-size request detected")
    if any(x in s for x in ("old","unused","stale")): return Intent("old",target(s),.89,"stale-file request detected")
    if any(x in s for x in ("scan","inspect","find","show","analyze","analyse","check")): return Intent("scan",target(s),.90,"filesystem inspection request detected")
    return Intent("chat",".",.55,"no filesystem action confidently detected")

def target(s):
    m=re.findall(r'["\']([^"\']+)["\']',s)
    if m:return m[-1]
    for marker in (" in "," under "," from "," at "," on "):
        if marker in s:return s.split(marker,1)[1].strip()
    return "."
