from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib, os, time

@dataclass
class FileRecord:
    path: Path
    size: int
    age_days: float
    kind: str
    stale: bool
    reason: str = ""

TEMP_NAMES = {".tmp",".temp",".cache",".log",".bak",".old",".part","__pycache__",".gradle",".pytest_cache"}
GENERATED_EXTENSIONS = {".pyc",".class",".o",".obj",".apk",".aab",".dex",".tmp",".part",".bak",".log"}

def _kind(path: Path) -> str:
    n, s = path.name.lower(), path.suffix.lower()
    if n in TEMP_NAMES or any(p.lower() in TEMP_NAMES for p in path.parts): return "temporary/generated"
    if s in GENERATED_EXTENSIONS: return "generated/artifact"
    if s in {".zip",".7z",".rar",".tar",".gz"}: return "archive"
    if s in {".jpg",".jpeg",".png",".gif",".webp",".mp4",".mkv",".mov"}: return "media"
    if s in {".py",".js",".ts",".java",".kt",".rs",".go",".c",".cpp",".h"}: return "source"
    if s in {".pdf",".doc",".docx",".txt",".md"}: return "document"
    return "file"

def scan(path: str|Path, stale_days: int=90, max_files: int=10000) -> list[FileRecord]:
    root = Path(path).expanduser()
    if not root.exists(): raise FileNotFoundError(f"Path does not exist: {root}")
    now, results = time.time(), []
    if root.is_file(): candidates = [root]
    else:
        def walk():
            count = 0
            for base, dirs, files in os.walk(root, followlinks=False):
                dirs[:] = [d for d in dirs if d not in {".git",".venv","venv"}]
                for name in files:
                    if count >= max_files: return
                    count += 1
                    yield Path(base)/name
        candidates = walk()
    for p in candidates:
        try: st = p.stat()
        except (OSError, PermissionError): continue
        age = max(0.0, (now-st.st_mtime)/86400.0)
        stale = age >= stale_days
        results.append(FileRecord(p, st.st_size, age, _kind(p),
                                  stale, f"not modified for {age:.0f} days" if stale else ""))
    return results

def find_stale(path, stale_days=90):
    return [r for r in scan(path, stale_days) if r.stale]

def find_large(path, min_bytes=100*1024*1024):
    return [r for r in scan(path) if r.size >= min_bytes]

def _hash(path, chunk_size=1024*1024):
    h=hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(chunk_size): h.update(chunk)
    return h.hexdigest()

def find_duplicates(path):
    groups={}
    for r in scan(path):
        if r.size:
            groups.setdefault((r.size,_hash(r.path)),[]).append(r)
    return [g for g in groups.values() if len(g)>1]
