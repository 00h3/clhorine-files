"""Live public-web search using DuckDuckGo's HTML endpoint.

This is a lightweight fallback with no API key. Search engines can change their
HTML, so results are best-effort. For production, plug in a stable search API.
"""
from html.parser import HTMLParser
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen
import re

class ResultParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.results=[]; self.href=None; self.text=[]
        self.in_result=False
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if tag=="a" and a.get("class") and "result__a" in a["class"]:
            self.href=a.get("href"); self.text=[]; self.in_result=True
    def handle_data(self,data):
        if self.in_result: self.text.append(data)
    def handle_endtag(self,tag):
        if tag=="a" and self.in_result:
            title=" ".join("".join(self.text).split())
            if self.href and title:
                self.results.append({"title":title,"url":self.href,"snippet":""})
            self.in_result=False

def search(query, max_results=8, timeout=12):
    url="https://html.duckduckgo.com/html/?q="+quote(query)
    req=Request(url,headers={"User-Agent":"Chlorine/0.5 (research tool)"})
    try:
        html=urlopen(req,timeout=timeout).read().decode("utf-8","ignore")
    except Exception as e:
        return [{"error":str(e)}]
    p=ResultParser(); p.feed(html)
    return p.results[:max_results]

def fetch_text(url, timeout=15, max_chars=20000):
    req=Request(url,headers={"User-Agent":"Chlorine/0.5 (page reader)"})
    raw=urlopen(req,timeout=timeout).read().decode("utf-8","ignore")
    raw=re.sub(r"(?is)<script.*?>.*?</script>"," ",raw)
    raw=re.sub(r"(?is)<style.*?>.*?</style>"," ",raw)
    raw=re.sub(r"(?s)<[^>]+>"," ",raw)
    return re.sub(r"\s+"," ",raw).strip()[:max_chars]
