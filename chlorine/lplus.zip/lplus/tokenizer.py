"""Small byte-level tokenizer.

Byte-level tokenization avoids needing a huge vocabulary and works for arbitrary
UTF-8 text. It is deliberately simple so the training pipeline is inspectable.
"""
class ByteTokenizer:
    PAD = 256
    BOS = 257
    EOS = 258
    UNK = 259
    VOCAB_SIZE = 260

    def encode(self, text, add_bos=True, add_eos=True):
        raw = text.encode("utf-8", errors="replace")
        ids = [b for b in raw]
        if add_bos:
            ids.insert(0, self.BOS)
        if add_eos:
            ids.append(self.EOS)
        return ids

    def decode(self, ids):
        raw = bytes(i for i in ids if 0 <= i < 256)
        return raw.decode("utf-8", errors="replace")

    def save(self, path):
        open(path, "w", encoding="utf-8").write(
            '{"type":"byte","vocab_size":260}\n'
        )
