# The previous lightweight model is retained for low-RAM environments.
from collections import Counter, defaultdict
import math, pickle, random, re

class LegacyLPlus:
    def __init__(self, order=3):
        self.order=order; self.counts=defaultdict(Counter); self.totals=Counter(); self.vocab=Counter()
    def train(self, text):
        toks=re.findall(r"\w+|[^\w\s]", text.lower())
        self.vocab.update(toks)
        for i,t in enumerate(toks):
            c=tuple(toks[max(0,i-self.order+1):i]); self.counts[c][t]+=1; self.totals[c]+=1
        return len(toks)
    def generate(self,prompt="",max_tokens=60):
        out=re.findall(r"\w+|[^\w\s]",prompt.lower())
        for _ in range(max_tokens):
            c=tuple(out[-(self.order-1):]); choices=self.counts.get(c,self.vocab)
            if not choices: break
            out.append(random.choice(list(choices.elements())))
        s=""
        for t in out: s += t if not s or re.match(r"^[^\w\s]$",t) else " "+t
        return s
    def save(self,path): pickle.dump(self,open(path,"wb"))
    @classmethod
    def load(cls,path): return pickle.load(open(path,"rb"))
