import math, time
from pathlib import Path
import torch
from torch.optim import AdamW
from .model import LPlus, LPlusConfig
from .tokenizer import ByteTokenizer

def make_batch(data, block_size, batch_size, device):
    starts=torch.randint(0,len(data)-block_size-1,(batch_size,))
    x=torch.stack([data[i:i+block_size] for i in starts]).to(device)
    y=torch.stack([data[i+1:i+block_size+1] for i in starts]).to(device)
    return x,y

def train(data_path,out_path,steps=2000,batch_size=16,lr=3e-4,block_size=256,device=None):
    device=device or ("cuda" if torch.cuda.is_available() else "cpu")
    tok=ByteTokenizer()
    text=Path(data_path).read_text(encoding="utf-8")
    ids=torch.tensor(tok.encode(text),dtype=torch.long)
    split=int(.9*len(ids)); tr,va=ids[:split],ids[split:]
    cfg=LPlusConfig(block_size=block_size)
    model=LPlus(cfg).to(device)
    opt=AdamW(model.parameters(),lr=lr,weight_decay=.1)
    model.train()
    for step in range(1,steps+1):
        x,y=make_batch(tr,block_size,batch_size,device)
        _,loss=model(x,y)
        opt.zero_grad(set_to_none=True); loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
        if step==1 or step%100==0:
            model.eval()
            with torch.no_grad():
                vx,vy=make_batch(va,block_size,min(batch_size,4),device)
                _,vl=model(vx,vy)
            model.train()
            print(f"step={step} train_loss={loss.item():.4f} val_loss={vl.item():.4f}")
            model.save_checkpoint(out_path,opt,step)
    print("saved",out_path,"on",device)
